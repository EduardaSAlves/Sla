import javax.swing.JOptionPane;

public class Candidato {
	private String nome;
	private String cursoFormacao;
	private int tempoExperiencia;
	private String cpf;
	private String telefone;
	
	
	
public String getNome() {
		return nome;
	}
public void setNome(String nome) {
		this.nome = nome;
	}
public String getCursoFormacao() {
		return cursoFormacao;
	}
public void setCursoFormacao(String cursoFormacao) {
		this.cursoFormacao = cursoFormacao;
	}
public int getTempoExperiencia() {
		return tempoExperiencia;
	}
public void setTempoExperiencia(int tempoExperiencia) {
		this.tempoExperiencia = tempoExperiencia;
	}
public String getCpf() {
		return cpf;
	}
public void setCpf(String cpf) {
		this.cpf = cpf;
	}
public String getTelefone() {
		return telefone;
	}
public void setTelefone(String telefone) {
		this.telefone = telefone;
	}



	public void cadastro() {
		nome = JOptionPane.showInputDialog("Nome:");
			telefone = JOptionPane.showInputDialog("Telefone:");
				cpf = JOptionPane.showInputDialog("CPF:");
					cursoFormacao = JOptionPane.showInputDialog("Escolha uma op��o de curso (SI ou EP): \n Sistemas da Informa��o \n Engenharia de Produ��o " );
					cursoFormacao.toUpperCase();
					while (!(cursoFormacao.equalsIgnoreCase("SI")) && !(cursoFormacao.equalsIgnoreCase("EP"))){
						cursoFormacao = JOptionPane.showInputDialog("Escolha uma op��o de curso (SI ou EP): \n Sistemas da Informa��o \n 2- Engenharia de Produ��o " );
						}
				
						   String aux = JOptionPane.showInputDialog("Tempo de Experi�ncia (meses) :");
						   tempoExperiencia = Integer.parseInt(aux);
						 
								
	}
	@Override
	public String toString() {

		return "Candidato "
				+ "\n Nome = " + nome + ""
						+ "\n Curso de Forma��o = " +cursoFormacao.toUpperCase()+
						"\n Tempo  de Experiencia = " + tempoExperiencia + " meses" ;
	}
	
	
	
}

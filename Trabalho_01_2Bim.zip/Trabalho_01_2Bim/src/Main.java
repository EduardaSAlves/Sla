import javax.swing.JOptionPane;
//3. Consulta o maior tempo de experi�ncia dos candidatos: ler do teclado a �rea de forma��o que se deseja consultar e
//apresenta todas as informa��es do registro do candidato com maior tempo entre todos os presentes na ABB (o �ltimo a
//ser inserido na ABB, caso haja 2 candidatos com mesmo tempo de experi�ncia). Para isso, deve ser criado um m�todo que
//apresente na tela de sa�da as informa��es do candidato e gere como retorno o n�mero de compara��es realizadas at�
//que o candidato com maior tempo de experiencia seja encontrado.

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ABBEP arvoreEP = new ABBEP();
		ABBSI arvoreSI = new ABBSI();
		String consultaMaior;

		String resp = JOptionPane.showInputDialog(null,
				"Escolha uma op��o: \n 1-Cadastrar candidato " + "\n 2-Abertura da vaga "
						+ "\n 3-Consulta de maior tempo de experi�ncia " + "\n 4-Encerrar programa  ");

		while (resp.equalsIgnoreCase("1")) {
			Candidato candidato = new Candidato();

			candidato.cadastro();
			if (candidato.getCursoFormacao().equalsIgnoreCase("SI")) {
				arvoreSI.root = arvoreSI.inserir(arvoreSI.root, candidato);
				arvoreSI.inOrdem(arvoreSI.root);
			} else {
				arvoreEP.root = arvoreEP.inserir(arvoreEP.root, candidato);
				arvoreEP.inOrdem(arvoreEP.root);
			}

			resp = JOptionPane.showInputDialog(null,
					"Escolha uma op��o: \n 1-Cadastrar candidato \n 2-Abertura da vaga \n 3-Consulta de maior tempo de experi�ncia \n 4-Encerrar programa  ");

		}
		while (resp.equalsIgnoreCase("3")) {
			int cont = 0;
			Candidato aux = new Candidato();
			consultaMaior = JOptionPane.showInputDialog("Digite o curso de forma��o desejado: (SI/EP)");
			consultaMaior.toUpperCase();
			if (consultaMaior.equalsIgnoreCase("EP")) {
				arvoreEP.MaiorExp(arvoreEP.root, aux);

				arvoreEP.contaConsulta(arvoreEP.root, aux, cont );

			} else {
				arvoreSI.MaiorExp(arvoreSI.root, aux);
				arvoreEP.contaConsulta(arvoreEP.root, aux, cont);
			}

			JOptionPane.showMessageDialog(null, "Candidato com maior tempo de experi�ncia:" + aux.toString() +"\n N�mero de compara��es: "+cont );
			resp = JOptionPane.showInputDialog(null,
					"Escolha uma op��o: \n 1-Cadastrar candidato \n 2-Abertura da vaga \n 3-Consulta de maior tempo de experi�ncia \n 4-Encerrar programa  ");
		}
		while (resp.equalsIgnoreCase("4")) {

			break;
		}

	}

}

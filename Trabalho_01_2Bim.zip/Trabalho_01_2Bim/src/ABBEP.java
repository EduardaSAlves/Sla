

public class ABBEP {

		private class ARVORE {
			Candidato dado;
			ARVORE dir, esq;
		}

		public ARVORE root = null;

		public ARVORE inserir(ARVORE p, Candidato info) {
			// insere elemento em uma ABB
			if (p == null) {
				p = new ARVORE();
				p.dado = info;
				p.esq = null;
				p.dir = null;
			} else if (info.getTempoExperiencia() > p.dado.getTempoExperiencia())
				p.esq = inserir(p.esq, info);
			else
				p.dir = inserir(p.dir, info);
			return p;
		}
		public void MaiorExp(ARVORE p, Candidato c) {
			c  = p.esq.dado;
		
		}
		
		public void inOrdem(ARVORE p) {
			if (p != null) {
				if (p.esq != null)
					inOrdem(p.esq);
				System.out.println( p.dado.toString());
				if (p.dir != null)
					inOrdem(p.dir);
				}

	}

		public void posOrdem(ARVORE p) {
			if (p != null) {
				if (p.esq != null)
					posOrdem(p.esq);
				if (p.dir != null)
					posOrdem(p.dir);
				System.out.println("dado: " + p.dado);
			}
		}

		public int contaNos(ARVORE p, int cont) {
			if (p != null) {
				cont++;
				if (p.esq != null)
					cont = contaNos(p.esq, cont);
				if (p.dir != null)
					cont = contaNos(p.dir, cont);
			}
			return cont;
		}

		public boolean consulta(ARVORE p, Candidato info) {
			// procura elemento na �rvore retornando true caso encontre
			// or false se o elemento n�o for encontrado

			boolean achou = false;

			if (p != null) {
				if (p.dado.getTempoExperiencia() == info.getTempoExperiencia())
					return true;
				else {
					if (info.getTempoExperiencia() > p.dado.getTempoExperiencia())
						achou = consulta(p.dir, info);
					else
						achou = consulta(p.esq, info);
				}
			}
			return  achou;
		}

		public int contaConsulta(ARVORE p, Candidato info, int cont) {
			if (p != null) {
				cont++;
				if (p.dado == info)
					return cont;
				else {
					if (info.getTempoExperiencia() > p.dado.getTempoExperiencia())
						cont = contaConsulta(p.dir, info, cont);
					else
						cont = contaConsulta(p.esq, info, cont);
				}
			}
			return cont;
		}

		public ARVORE removeValor(ARVORE p, Candidato info) {
			if (p != null) {
				if (info == p.dado) {
					if (p.esq == null && p.dir == null) // n� a ser removido � n� folha
						return null;
					if (p.esq == null) { // se n�o h� sub-�rvore esquerda o ponteiro passa apontar para a sub-�rvore
											// direita
						return p.dir;
					} else {
						if (p.dir == null) { // se n�o h� sub-�rvore direita o ponteiro passa apontar para a sub-�rvore
												// esquerda
							return p.esq;
						} else {
							// o n� a ser retirado possui sub-arvore esquerda e direita, ent�o o n� que ser�
							// retirado deve-se encontrar o menor valor na sub-�rvore � direita
							ARVORE aux, ref;
							ref = p.dir;
							aux = p.dir;
							while (aux.esq != null)
								aux = aux.esq;
							aux.esq = p.esq;
							return ref;
						}
					}
				} else {
					// procura dado a ser removido na ABB
					if (info.getTempoExperiencia() < p.dado.getTempoExperiencia())
						p.esq = removeValor(p.esq, info);
					else
						p.dir = removeValor(p.dir, info);
				}
			}
			return p;
		}

		
	}
